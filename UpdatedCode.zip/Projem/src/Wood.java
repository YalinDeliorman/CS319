public class Wood extends Weapon {

	public Wood(String imagepath, float x, float y) {
		super(imagepath,x, y);
		super.power=5;
		
	}

	@Override
	public void collided(GameObject g) {
		// TODO Auto-generated method stub
		
	}




}
