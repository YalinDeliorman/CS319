public class Meat extends Food {

	public Meat (float x, float y) {
		super("Images//meat.gif", x, y);
		 foodHealth=25;
	}
}
