public class Bullet extends Weapon {

	public Bullet(float x, float y) {
		super("Images//Glenos-G_160_bullet.png", x, y);
		super.power = 20;
	}

	@Override
	public void collided(GameObject g) {
		// TODO Auto-generated method stub
		
	}




}
