
public class WillSawyer extends Creature {

	public WillSawyer (float x, float y) {
		super("Images//sawyer png.png", x, y);
		damage=75;
	}

}
