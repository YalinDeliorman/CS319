public class Sugar extends Food {

	public Sugar (float x, float y) {
		super("Images//candy.png", x, y);
		 foodHealth=25;
	}
}
