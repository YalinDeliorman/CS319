public class LaserGun extends Weapon
{
	public LaserGun(String imagepath, float x, float y) {
		super(imagepath, x,y);
		super.power=30;
	}

	@Override
	public void collided(GameObject g) {
		// TODO Auto-generated method stub
		
	}




}
