public class Vegetable extends Food {

	public Vegetable (float x, float y) {
		super("Images//david png.png", x, y);
		 foodHealth=50;
	}
}
