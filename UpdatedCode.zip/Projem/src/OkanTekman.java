public class OkanTekman extends Creature {

	public OkanTekman(float x, float y) {
		super("Images//teqman png.png", x, y);
		damage=50;
	}

}