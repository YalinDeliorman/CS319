public class DavidDavenport extends Creature {

	public DavidDavenport(float x, float y) {
		super("Images//david png.png", x, y);
		damage=25;
	}

}
