import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame {
	private JPanel currentPanel;
	public MainFrame(JPanel currentPanel,String title){
		super(title);
		setLocation(50,50);
		setSize(1000,600);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.currentPanel=currentPanel;
		add(currentPanel);
		setVisible(true);
	}
	public void startGame(){
		remove(currentPanel);
		currentPanel=new SelectModePanel(this);
		add(currentPanel);
		repaint();
		
	}
	public void highscores(){
		
	}
	public void tutorial(){			
		remove(currentPanel);
		currentPanel=new TutorialPanel(this);
		add(currentPanel);
		repaint();
		
	}
	public void credits(){
		remove(currentPanel);
		currentPanel=new CreditPanel(this);
		add(currentPanel);
		repaint();
		
	}
	public void settings(){
		remove(currentPanel);
		currentPanel=new SettingPanel(this);
		add(currentPanel);
		repaint();
		
	}
	public void backToMenu(){
		/*
			removeKeyListener(gamer);
			removeMouseListener(gamer);
			removeMouseMotionListener(gamer);
			*/
			remove(currentPanel);
			currentPanel=new MenuPanel();
			((MenuPanel)currentPanel).setFrame(this);
			add(currentPanel);
			repaint();
		
	}
	
}
