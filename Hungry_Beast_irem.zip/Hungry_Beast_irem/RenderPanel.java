
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;


public class RenderPanel extends JPanel{

	private static final long serialVersionUID = 1L;
	private ArrayList<GameObject> objects;
	public RenderPanel(){
		setLocation(0,0);
		setSize(1000,500);
		setLayout(null);
		setBackground(Color.BLUE);
		objects = new ArrayList<GameObject>();
	}
	public ArrayList<GameObject> getGameObjects(){
		return objects;
	}
	public void setGameObjects(ArrayList<GameObject> object){
		this.objects=object;
	}
	public void paintComponent(Graphics g){
		
		super.paintComponent(g);
		g.clearRect(0, 0, getWidth(), getHeight());
		
		g.setColor(Color.WHITE);
		
		for (int i = 0; i < objects.size(); i++) {
			
			GameObject gobj = objects.get(i);

			int height = gobj.getImage().getHeight();
			int width = gobj.getImage().getWidth();
			
			if(gobj instanceof Beast){
				Beast b = (Beast)gobj;
				g.setColor(Color.yellow);
				/*
				for (int j = 0; j < p.getTrail().length; j++) {
					if(p.getTrail()[j]!=null)
						g.drawOval((int)p.getTrail()[j].getX(),(int) (getHeight()-p.getTrail()[j].getY()), 2, 2);
				}
				*/
				g.setColor(Color.black);
			}
			g.drawImage(gobj.getImage(), (int)(gobj.getPosition().getX() - (width / 2)), 
					(int)(getHeight() - (gobj.getPosition().getY() + (height / 2))), null); 
		}
	}

}

