import java.util.ArrayList;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
public class GameDynamicsEngine extends Thread implements KeyListener{
	private ArrayList <GameObject> objects;
	private RenderPanel rp;
	private Beast beast;
	private boolean started; 
	private MainFrame frame;
	private SettingPanel settings;
	private SelectModePanel modePanel;
	private Vector2D newGobjPos;
	
	private boolean goOn=true;
	public GameDynamicsEngine(MainFrame frame,SettingPanel settings,SelectModePanel modePanel){
		this.newGobjPos=null;
		this.frame=frame;
		this.settings=settings;
		this.modePanel=modePanel;
		started=false;
		objects=new ArrayList<GameObject>();
		beast=new Beast("Images\\chewy base.png", 300,300);
		rp=new RenderPanel();
		objects.add(beast);
	}

	@Override
	public void keyPressed(KeyEvent e) {//esc ise ��k
		if (e.getKeyCode()==27) {
			goOn = false;
			menu();
		}
		else if(e.getKeyCode()==32){//space ise ate� et
			shoot();
			started=true;
		}
		else if(settings.getControls()){
			 if(e.getKeyCode()==39){//sa�a git
				
				beast.translateX(5);
			}
			else if(e.getKeyCode()==37){//sola git
				
				beast.translateX(-5);
			}
		}
		else if(!settings.getControls()){
			if(e.getKeyCode()==68){//sa�a git
				
				beast.translateX(5);
			}
			else if(e.getKeyCode()==65){//sola git
				
				beast.translateX(-5);
			}
		}
		
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void menu(){
		frame.backToMenu();
		}
public void shoot(){
	
}

}
	